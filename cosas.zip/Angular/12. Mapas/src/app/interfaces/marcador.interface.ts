export interface Marcador{

  lat: number;
  lng: number;
  draggable:boolean;

  titulo:string;
  desc?:string;

}
