

export interface Mensaje{
  nombre:string;
  mensaje:string;
  uid?:string;
}
