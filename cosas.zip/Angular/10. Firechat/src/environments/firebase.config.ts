// Must export the config
export const firebaseConfig = {
  apiKey: "AIzaSyCbGAtpyQtuy3YI20GYCH2XyhHzrN7Cj3Y",
  authDomain: "firechat-cb2bb.firebaseapp.com",
  databaseURL: "https://firechat-cb2bb.firebaseio.com",
  storageBucket: "firechat-cb2bb.appspot.com",
  messagingSenderId: "857173887701"
};
